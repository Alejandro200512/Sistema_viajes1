#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "agendar.h"
#include <QMessageBox> //caja de texto
#include <QTableWidgetItem>

#include <QFile>    //Me permite abrir archivos,crear,modificar,ademas de verificar si existe cierto archivo
#include <QTextStream>
#include <QFileDialog> //me permite  abirr un archivo o guardarlo desde cualquier aplicacion.

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableRegistro->setColumnCount(8);
    QStringList headers = {"Cédula", "Nombre", "Destino", "Días", "Adultos", "Mayores", "Niños", "Total"};
    ui->tableRegistro->setHorizontalHeaderLabels(headers);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionColaboradores_triggered()
{
    QMessageBox::information(this, "Colaboradores", "Proyecto realizado por:"
                                                    " \nArequipa Concepcion "
                                                    "\nInlago Dylan "
                                                    "\nGuato David "
                                                    "\nSuarez Melva"
                                                                                        );
}

void MainWindow::on_actionSobre_qt_triggered()
{
    QMessageBox::aboutQt(this);
}

void MainWindow::on_btnAgregar_clicked()
{
    agendar dialogo;
    if (dialogo.exec() == QDialog::Accepted) {
        QString cedulaNueva = dialogo.getCedula();

        // Verificar si la cédula ya existe en la tabla
        for (int i = 0; i < ui->tableRegistro->rowCount(); ++i) {
            QString cedulaExistente = ui->tableRegistro->item(i, 0)->text();
            if (cedulaExistente == cedulaNueva) {
                QMessageBox::warning(this, "Cédula repetida", "La cédula ingresada ya está registrada.");
                return; // No agregar el registro
            }
        }

        // Si no está repetida, agregar el registro
        int row = ui->tableRegistro->rowCount();
        ui->tableRegistro->insertRow(row);

        ui->tableRegistro->setItem(row, 0, new QTableWidgetItem(cedulaNueva));
        ui->tableRegistro->setItem(row, 1, new QTableWidgetItem(dialogo.getNombre()));
        ui->tableRegistro->setItem(row, 2, new QTableWidgetItem(dialogo.getDestino()));
        ui->tableRegistro->setItem(row, 3, new QTableWidgetItem(QString::number(dialogo.getDias())));
        ui->tableRegistro->setItem(row, 4, new QTableWidgetItem(QString::number(dialogo.getAdultos())));
        ui->tableRegistro->setItem(row, 5, new QTableWidgetItem(QString::number(dialogo.getAdultosMayores())));
        ui->tableRegistro->setItem(row, 6, new QTableWidgetItem(QString::number(dialogo.getNinos())));
        ui->tableRegistro->setItem(row, 7, new QTableWidgetItem(QString::number(dialogo.getTotalPagar(), 'f', 2)));
    }
}


void MainWindow::on_btnModificar_clicked()
{
    int row = ui->tableRegistro->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "Modificar", "Seleccione una fila para modificar.");
        return;
    }

    agendar dialogo;

    dialogo.setCedula(ui->tableRegistro->item(row, 0)->text());
    dialogo.setNombre(ui->tableRegistro->item(row, 1)->text());
    dialogo.setDestino(ui->tableRegistro->item(row, 2)->text());
    dialogo.setDias(ui->tableRegistro->item(row, 3)->text().toInt());
    dialogo.setAdultos(ui->tableRegistro->item(row, 4)->text().toInt());
    dialogo.setMayores(ui->tableRegistro->item(row, 5)->text().toInt());
    dialogo.setNinos(ui->tableRegistro->item(row, 6)->text().toInt());

    if (dialogo.exec() == QDialog::Accepted) {
        ui->tableRegistro->setItem(row, 0, new QTableWidgetItem(dialogo.getCedula()));
        ui->tableRegistro->setItem(row, 1, new QTableWidgetItem(dialogo.getNombre()));
        ui->tableRegistro->setItem(row, 2, new QTableWidgetItem(dialogo.getDestino()));
        ui->tableRegistro->setItem(row, 3, new QTableWidgetItem(QString::number(dialogo.getDias())));
        ui->tableRegistro->setItem(row, 4, new QTableWidgetItem(QString::number(dialogo.getAdultos())));
        ui->tableRegistro->setItem(row, 5, new QTableWidgetItem(QString::number(dialogo.getAdultosMayores())));
        ui->tableRegistro->setItem(row, 6, new QTableWidgetItem(QString::number(dialogo.getNinos())));
        ui->tableRegistro->setItem(row, 7, new QTableWidgetItem(QString::number(dialogo.getTotalPagar(), 'f', 2)));
    }
}






void MainWindow::on_btnGuardar_clicked()
{
    QString nombreArchivo = QFileDialog::getSaveFileName(this, "Guardar Factura", "", "Archivos de texto (*.txt)");

    if (nombreArchivo.isEmpty()) {
        return; // Usuario canceló
    }

    QFile archivo(nombreArchivo);
    if (!archivo.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo para escribir.");
        return;
    }

    QTextStream out(&archivo);
    out << "========= FACTURA DE REGISTROS =========\n\n";

    int filas = ui->tableRegistro->rowCount();

    for (int i = 0; i < filas; ++i) {
        // Validacion de las filas del main principal

        QString cedula   = ui->tableRegistro->item(i, 0) ? ui->tableRegistro->item(i, 0)->text() : "";
        QString nombre   = ui->tableRegistro->item(i, 1) ? ui->tableRegistro->item(i, 1)->text() : "";
        QString destino  = ui->tableRegistro->item(i, 2) ? ui->tableRegistro->item(i, 2)->text() : "";
        QString dias     = ui->tableRegistro->item(i, 3) ? ui->tableRegistro->item(i, 3)->text() : "";
        QString adultos  = ui->tableRegistro->item(i, 4) ? ui->tableRegistro->item(i, 4)->text() : "";
        QString mayores  = ui->tableRegistro->item(i, 5) ? ui->tableRegistro->item(i, 5)->text() : "";
        QString ninos    = ui->tableRegistro->item(i, 6) ? ui->tableRegistro->item(i, 6)->text() : "";
        QString total    = ui->tableRegistro->item(i, 7) ? ui->tableRegistro->item(i, 7)->text() : "";

        //tomo los valores buscadosy encontrados para ponerlos en la factura a parte

        out << "Registro #" << i + 1 << ":\n";

        out << "Cédula: " << cedula << "\n";

        out << "Nombre: " << nombre << "\n";

        out << "Destino: " << destino << "\n";
        out << "Días: " << dias << "\n";
        out << "Adultos: " << adultos << "\n";
        out << "Mayores: " << mayores << "\n";
        out << "Niños: " << ninos << "\n";
        out << "Total a pagar: " << total << "\n";
        out << "----------------------------------------\n\n";
    }

    archivo.close();

    QMessageBox::information(this, "Factura guardada", "La factura ha sido guardada correctamente.");

}


void MainWindow::on_btnCargarArchivo_clicked()
{
    QString archivo = QFileDialog::getOpenFileName(this, "Abrir archivo", "", "Archivos de texto (*.txt)");

    if (archivo.isEmpty())
        return;

    QFile file(archivo);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo.");
        return;
    }

    //esta linea nos ayuda a limpiar los registros que pueda que esten para no confundirlos
    ui->tableRegistro->setRowCount(0);

    QTextStream in(&file);
    QString linea;
    QStringList datos;
    int row = -1;

    while (!in.atEnd()) {
        linea = in.readLine();

        if (linea.startsWith("Registro")) {
            row++;
            ui->tableRegistro->insertRow(row);
            datos.clear();
        } else if (linea.startsWith("Cédula:")) {
            QString cedula = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 0, new QTableWidgetItem(cedula));
        } else if (linea.startsWith("Nombre:")) {
            QString nombre = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 1, new QTableWidgetItem(nombre));
        } else if (linea.startsWith("Destino:")) {
            QString destino = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 2, new QTableWidgetItem(destino));
        } else if (linea.startsWith("Días:")) {
            QString dias = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 3, new QTableWidgetItem(dias));
        } else if (linea.startsWith("Adultos:")) {
            QString adultos = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 4, new QTableWidgetItem(adultos));
        } else if (linea.startsWith("Mayores:")) {
            QString mayores = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 5, new QTableWidgetItem(mayores));
        } else if (linea.startsWith("Niños:")) {
            QString ninos = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 6, new QTableWidgetItem(ninos));
        } else if (linea.startsWith("Total a pagar:")) {
            QString total = linea.mid(linea.indexOf(":") + 2);
            ui->tableRegistro->setItem(row, 7, new QTableWidgetItem(total));
        }
    }

    file.close();
}

void MainWindow::on_pushButton_clicked()
{int filaSeleccionada = ui->tableRegistro->currentRow();

    if (filaSeleccionada < 0) {
        QMessageBox::warning(this, "Eliminar fila", "Selecciona una fila para eliminar.");
        return;
    }

    ui->tableRegistro->removeRow(filaSeleccionada);

}

