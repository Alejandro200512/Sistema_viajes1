#ifndef AGENDAR_H
#define AGENDAR_H

#include <QDialog>

namespace Ui {
class agendar;
}

class agendar : public QDialog
{
    Q_OBJECT

public:
    explicit agendar(QWidget *parent = nullptr);
    ~agendar();

    // Métodos para tomar los valores de la tabla
    QString getCedula() const;
    QString getNombre() const;
    QString getDestino() const;
    int getDias() const;
    int getAdultos() const;
    int getAdultosMayores() const;
    int getNinos() const;
    int getEdad();
    double getTotalPagar() const;

    // Recuperar la factura
    QString obtenerNombre() const;
    QString obtenerCedula() const;
    QString obtenerDestino() const;
    int obtenerDias() const;
    int obtenerAdultos() const;
    int obtenerMayores() const;
    int obtenerNinos() const;

    // Modificar los datos
    void setNombre(const QString &nombre);
    void setCedula(const QString &cedula);
    void setDestino(const QString &destino);
    void setDias(int dias);
    void setAdultos(int adultos);
    void setMayores(int mayores);
    void setNinos(int ninos);
    void setTotal(const QString &total);

private slots:

    void on_buttonBox_accepted();
    void on_buttonBox_rejected();
    void actualizarTotalPersonas();

private:
    Ui::agendar *ui;
    double totalPagar = 0.0;  // toma el valor del label en entero
};

#endif // AGENDAR_H
