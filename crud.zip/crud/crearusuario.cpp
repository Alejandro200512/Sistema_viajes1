#include "crearusuario.h"
#include "ui_crearusuario.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

crearUsuario::crearUsuario(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::crearUsuario)
{
    ui->setupUi(this);
    ui->txtPasswordNew->setEchoMode(QLineEdit::Password);
}

crearUsuario::~crearUsuario()
{
    delete ui;
}

void crearUsuario::on_btnCrearUsuario_clicked()
{
    QString usuario = ui->txtNuevoUsuario->text();
    QString password = ui->txtPasswordNew->text();

    if (usuario.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Campos vacíos", "Completa todos los campos.");
        return;
    }

    QFile archivo("usuarios.txt");

    if (!archivo.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo.");
        return;
    }

    QTextStream out(&archivo);
    out << usuario << "," << password << "\n";

    archivo.close();

    QMessageBox::information(this, "Usuario creado", "Usuario creado exitosamente.");
    this->accept();
}


