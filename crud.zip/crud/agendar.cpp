#include "agendar.h"
#include "ui_agendar.h"
#include <QTableWidget> //Trabajo con las herramientas para la tabla principal
#include <QRegularExpressionValidator> //Biblioteca apra tomar valores expresivos (numeros)

agendar::agendar(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::agendar)


{
    ui->setupUi(this);
    QRegularExpression rx("\\d{10}"); // toma la cedula solo con numeros no con caracteres
    QValidator *validator = new QRegularExpressionValidator(rx, this);
    ui->txtCedula->setValidator(validator);
    connect(ui->checkBoxHospedaje, &QCheckBox::toggled, ui->ComboxDias, &QComboBox::setEnabled); //señales para habilitar el hospedaje
    ui->ComboxDias->setEnabled(false); // DESACTIVA combo al inicio
    connect(ui->checkBoxHospedaje, &QCheckBox::toggled, ui->ComboxDias, &QComboBox::setEnabled);


    // LLeno los ComboBox de adultos,niños y adultos mayores de (0 a 5) para que el total de personas sean 15
    for (int i = 0; i <= 5; ++i) {
        ui->ComBoxAdultos->addItem(QString::number(i));
        ui->ComBoxMayores->addItem(QString::number(i));
        ui->ComBoxwawas->addItem(QString::number(i));
        connect(ui->ComBoxAdultos, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &agendar::actualizarTotalPersonas);
        connect(ui->ComBoxMayores, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &agendar::actualizarTotalPersonas);
        connect(ui->ComBoxwawas,  QOverload<int>::of(&QComboBox::currentIndexChanged), this, &agendar::actualizarTotalPersonas);



    }

    // Llenar ComboBox con el numero de dias disponibles(0-31)
    for (int i = 1; i <= 31; ++i) {
        ui->ComboxDias->addItem(QString::number(i));
    }

    //Muestra los destinos disponibles.
    QStringList destinos = { "Galapagos", "Manta", "Cuenca", "Ibarra" };
    ui->ComBoxDestino->addItems(destinos);
}


agendar::~agendar()
{
    delete ui;
}

void agendar::on_buttonBox_accepted()
{
     actualizarTotalPersonas();
    accept();
}


void agendar::on_buttonBox_rejected()
{
    reject();
}




QString agendar::getCedula() const { return ui->txtCedula->text(); }
QString agendar::getNombre() const { return ui->txtNombre->text(); }
QString agendar::getDestino() const { return ui->ComBoxDestino->currentText(); }
int agendar::getDias() const { return ui->ComboxDias->currentText().toInt(); }
int agendar::getAdultos() const { return ui->ComBoxAdultos->currentText().toInt(); }
int agendar::getAdultosMayores() const { return ui->ComBoxMayores->currentText().toInt(); }
int agendar::getNinos() const { return ui->ComBoxwawas->currentText().toInt(); }



void agendar::actualizarTotalPersonas() {
    int adultos = ui->ComBoxAdultos->currentText().toInt();
    int mayores = ui->ComBoxMayores->currentText().toInt();
    int ninos = ui->ComBoxwawas->currentText().toInt();
    int dias = ui->ComboxDias->currentText().toInt();
    QString destino = ui->ComBoxDestino->currentText();

    int total = adultos + mayores + ninos;
    ui->labelTotalPersonas->setText("Total de personas: " + QString::number(total));

    // Variables que estaban faltando:
    double hospedajePorDia = 0;
    double pasaje = 0;
    double totalHospedaje = 0;

    // Valores según destino
    if (destino == "Ibarra") {
        hospedajePorDia = 50.0;
        pasaje = 100.0;
    } else if (destino == "Manta") {
        hospedajePorDia = 60.0;
        pasaje = 120.0;
    } else if (destino == "Cuenca") {
        hospedajePorDia = 55.0;
        pasaje = 90.0;
    } else if (destino == "Galapagos") {
        hospedajePorDia = 45.0;
        pasaje = 80.0;
    }

    // Cálculo de hospedaje solo si está activado
    if (ui->checkBoxHospedaje->isChecked()) {
        totalHospedaje = hospedajePorDia * total * dias;
    }

    // Costo total de pasajes
    double totalPasaje = adultos * pasaje + mayores * (pasaje * 0.9) + ninos * (pasaje * 0.5);

     totalPagar = totalHospedaje + totalPasaje;

    ui->labelTotalPagar->setText("Total a pagar: $" + QString::number(totalPagar, 'f', 2));
}

int agendar::getEdad() {
    return ui->spinBoxEdad->value();
}



double agendar::getTotalPagar() const {
    return totalPagar;
}

QString agendar::obtenerNombre() const {
    return ui->txtNombre->text();
}

QString agendar::obtenerCedula() const {
    return ui->txtCedula->text();
}

QString agendar::obtenerDestino() const {
    return ui->ComBoxDestino->currentText();
}

int agendar::obtenerDias() const {
    return ui->ComboxDias->currentText().toInt(); // Si es un combo
}

int agendar::obtenerAdultos() const {
    return ui->ComBoxAdultos->currentText().toInt();
}

int agendar::obtenerMayores() const {
    return ui->ComBoxMayores->currentText().toInt();
}

int agendar::obtenerNinos() const {
    return ui->ComBoxwawas->currentText().toInt();
}


void agendar::setNombre(const QString &nombre) {
    ui->txtNombre->setText(nombre);
}

void agendar::setCedula(const QString &cedula) {
    ui->txtCedula->setText(cedula);
}

void agendar::setDestino(const QString &destino) {
    int index = ui->ComBoxDestino->findText(destino);
    if (index != -1) {
        ui->ComBoxDestino->setCurrentIndex(index);
    }
}

void agendar::setDias(int dias) {
    int index = ui->ComboxDias->findText(QString::number(dias));
    if (index != -1) {
        ui->ComboxDias->setCurrentIndex(index);
    }
}

void agendar::setAdultos(int adultos) {
    int index = ui->ComBoxAdultos->findText(QString::number(adultos));
    if (index != -1) {
        ui->ComBoxAdultos->setCurrentIndex(index);
    }
}

void agendar::setMayores(int mayores) {
    int index = ui->ComBoxMayores->findText(QString::number(mayores));
    if (index != -1) {
        ui->ComBoxMayores->setCurrentIndex(index);
    }
}

void agendar::setNinos(int ninos) {
    int index = ui->ComBoxwawas->findText(QString::number(ninos));
    if (index != -1) {
        ui->ComBoxwawas->setCurrentIndex(index);
    }
}

void agendar::setTotal(const QString &total) {
    ui->labelTotalPagar->setText("Total a pagar: $" + total);
}
