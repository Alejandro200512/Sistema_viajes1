#ifndef CREARUSUARIO_H
#define CREARUSUARIO_H

#include <QDialog>

namespace Ui {
class crearUsuario;
}

class crearUsuario : public QDialog
{
    Q_OBJECT

public:
    explicit crearUsuario(QWidget *parent = nullptr);
    ~crearUsuario();

private slots:

    void on_btnCrearUsuario_clicked();

private:
    Ui::crearUsuario *ui;
};

#endif
