#include "login.h"
#include "ui_login.h"
#include <QMessageBox>
#include <QString>
#include <QFile>
#include <QTextStream>
#include "crearusuario.h"

login::login(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);

    //Opcional establecer el campo de la contraseña en modo oculto
    ui->txtpassword->setEchoMode(QLineEdit::Password);

}

login::~login()
{
    delete ui;
}

void login::on_btnLogin_clicked()
{
    QString nombre = ui->txtNombre->text();
    QString contraseña = ui->txtpassword->text();

    if (nombre.isEmpty() || contraseña.isEmpty()) {
        QMessageBox::warning(this, "Campos vacíos", "Intenta completar todos los campos de nuevo.");
        return;
    }

    if (nombre == "admin" && contraseña == "1234") {
        QMessageBox::information(this, "Login exitoso", "Bienvenido " + nombre);
        accept();
        return;
    }

    // Compruebo la existencia de los usuarios creados en el archivo  usuarios.txt
    QFile archivo("usuarios.txt");

    if (archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&archivo);
        while (!in.atEnd()) {
            QString linea = in.readLine();
            QStringList partes = linea.split(",");

            if (partes.size() == 2 && partes[0] == nombre && partes[1] == contraseña) {
                QMessageBox::information(this, "Login exitoso", "Bienvenido " + nombre);
                accept();
                archivo.close();
                return;
            }
        }

        archivo.close();
    }

    QMessageBox::critical(this, "Error", "Nombre o contraseña incorrectos.");
}




void login::on_btnNuevoUsuario_clicked()
{
    crearUsuario ventanaCrear;
    ventanaCrear.exec();
}

